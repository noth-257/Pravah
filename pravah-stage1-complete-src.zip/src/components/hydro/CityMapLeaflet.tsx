import { useEffect } from "react";
import {
  CircleMarker,
  MapContainer,
  Polygon,
  Polyline,
  TileLayer,
  Tooltip,
  useMap,
} from "react-leaflet";
import type { LatLngExpression } from "leaflet";
import "leaflet/dist/leaflet.css";

import { cn } from "@/lib/utils";
import {
  CITY,
  DRAINS,
  RAIN_SENSORS,
  RIVER_PATH,
  ROADS,
  WATER_SENSORS,
  ZONES,
  type Zone,
} from "@/lib/hydro/data";
import { CONFIDENCE_VAR, confidenceBand } from "@/lib/hydro/ui";
import type { CityMapProps } from "./CityMap";

const RISK_COLORS = {
  low: "#22c55e",
  moderate: "#eab308",
  high: "#f97316",
  critical: "#ef4444",
} as const;

/*
 * Existing project overlays use an SVG coordinate system of 1000 × 640.
 * Stage 1 keeps those same demo geometries, but maps them onto real
 * geographic coordinates around Gorakhpur. Stage 3 can replace this adapter
 * with real GeoJSON without changing the map component API.
 */
const CENTER: LatLngExpression = [26.7606, 83.3732];
const X_CENTER = 500;
const Y_CENTER = 320;
const LAT_PER_UNIT = 0.000045;
const LNG_PER_UNIT = 0.00005;

function pointToLatLng([x, y]: [number, number]): [number, number] {
  return [
    (CENTER as [number, number])[0] - (y - Y_CENTER) * LAT_PER_UNIT,
    (CENTER as [number, number])[1] + (x - X_CENTER) * LNG_PER_UNIT,
  ];
}

function polygonToLatLng(points: string): [number, number][] {
  return points
    .trim()
    .split(/\s+/)
    .map((pair) => pair.split(",").map(Number))
    .filter((pair) => pair.length === 2 && pair.every(Number.isFinite))
    .map(([x, y]) => pointToLatLng([x, y] as [number, number]));
}

function pathToLatLng(path: string): [number, number][] {
  const values = [...path.matchAll(/-?\d+(?:\.\d+)?/g)].map((match) =>
    Number(match[0]),
  );
  const points: [number, number][] = [];
  for (let i = 0; i + 1 < values.length; i += 2) {
    points.push(pointToLatLng([values[i], values[i + 1]]));
  }
  return points;
}

function MapResizeHandler() {
  const map = useMap();

  useEffect(() => {
    const update = () => map.invalidateSize();

    const timer = window.setTimeout(update, 100);
    window.addEventListener("resize", update);

    const container = map.getContainer();
    const observer =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver(update)
        : null;

    observer?.observe(container);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("resize", update);
      observer?.disconnect();
    };
  }, [map]);

  return null;
}

export function CityMapLeaflet({
  step,
  layers,
  mode = "risk",
  selectedZoneId,
  onSelectZone,
  zoneLevelOverride,
  compact = false,
  className,
}: CityMapProps) {
  const has = (layer: string) => layers.includes(layer as never);
  const showConfidence = mode === "confidence" || has("confidence");

  return (
    <div
      className={cn(
        "map-scope relative h-full w-full overflow-hidden rounded-xl border border-border bg-surface",
        className,
      )}
    >
      <MapContainer
        center={CENTER}
        zoom={13}
        scrollWheelZoom
        className="hydropulse-leaflet-map"
      >
        <MapResizeHandler />

        {has("satellite") ? (
          <TileLayer
            attribution="Tiles &copy; Esri"
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
          />
        ) : (
          <TileLayer
            attribution="&copy; OpenStreetMap contributors"
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
        )}

        {/* City reference: keeps the existing project identity visible. */}
        {!compact ? (
          <CircleMarker
            center={CENTER}
            radius={4}
            pathOptions={{ color: "#38bdf8", fillColor: "#38bdf8", fillOpacity: 0.9 }}
          >
            <Tooltip direction="top" offset={[0, -4]} opacity={0.95}>
              {CITY.name}
            </Tooltip>
          </CircleMarker>
        ) : null}

        {/* Flood-risk zones */}
        {ZONES.map((zone) => {
          const forecast = zone.forecast[step];
          const level = zoneLevelOverride?.[zone.id] ?? forecast.level;
          const selected = selectedZoneId === zone.id;
          const color = showConfidence
            ? CONFIDENCE_VAR[confidenceBand(forecast.confidence)]
            : RISK_COLORS[level];

          return (
            <Polygon
              key={zone.id}
              positions={polygonToLatLng(zone.polygon)}
              pathOptions={{
                color: selected ? "#ffffff" : color,
                fillColor: color,
                fillOpacity: has("risk") || showConfidence ? (selected ? 0.42 : 0.2) : 0.04,
                weight: selected ? 4 : 2,
              }}
              eventHandlers={{
                click: () => onSelectZone?.(zone as Zone),
              }}
            >
              <Tooltip sticky>
                <div className="text-xs">
                  <strong>{zone.name}</strong>
                  <br />
                  Risk: {level.toUpperCase()}
                  <br />
                  Predicted depth: {forecast.depthMin}–{forecast.depthMax} cm
                </div>
              </Tooltip>
            </Polygon>
          );
        })}

        {/* Drainage network */}
        {has("drainage")
          ? DRAINS.map((drain) => (
              <Polyline
                key={drain.id}
                positions={pathToLatLng(drain.path)}
                pathOptions={{
                  color:
                    drain.status === "exceeded"
                      ? "#ef4444"
                      : drain.status === "stressed"
                        ? "#f97316"
                        : "#38bdf8",
                  weight: 3,
                  dashArray: "8 6",
                  opacity: 0.8,
                }}
              >
                <Tooltip sticky>{drain.name} · {drain.load}% load</Tooltip>
              </Polyline>
            ))
          : null}

        {/* River */}
        <Polyline
          positions={pathToLatLng(RIVER_PATH)}
          pathOptions={{
            color: "#38bdf8",
            weight: 10,
            opacity: 0.35,
          }}
        />

        {/* Affected roads */}
        {has("roads")
          ? ROADS.map((road) => {
              const severity = road.severity[step];
              if (!severity) return null;

              return (
                <Polyline
                  key={road.id}
                  positions={pathToLatLng(road.path)}
                  pathOptions={{
                    color: RISK_COLORS[severity],
                    weight: 6,
                    opacity: 0.85,
                  }}
                >
                  <Tooltip sticky>{road.name}</Tooltip>
                </Polyline>
              );
            })
          : null}

        {/* Rainfall sensors */}
        {has("rainfall")
          ? RAIN_SENSORS.map((sensor) => (
              <CircleMarker
                key={sensor.id}
                center={pointToLatLng(sensor.at)}
                radius={6}
                pathOptions={{
                  color: "#0ea5e9",
                  fillColor: "#0ea5e9",
                  fillOpacity: sensor.status === "live" ? 0.9 : 0.4,
                  weight: 2,
                }}
              >
                <Tooltip sticky>
                  {sensor.id} · {sensor.location}
                  <br />
                  Rainfall: {sensor.rainfall} mm/hr
                </Tooltip>
              </CircleMarker>
            ))
          : null}

        {/* Water-level sensors */}
        {has("sensors")
          ? WATER_SENSORS.map((sensor) => (
              <CircleMarker
                key={sensor.id}
                center={pointToLatLng(sensor.at)}
                radius={8}
                pathOptions={{
                  color: RISK_COLORS[sensor.risk],
                  fillColor: RISK_COLORS[sensor.risk],
                  fillOpacity: 0.9,
                  weight: 2,
                }}
              >
                <Tooltip sticky>
                  {sensor.id} · {sensor.location}
                  <br />
                  Water level: {sensor.levelCm} cm
                </Tooltip>
              </CircleMarker>
            ))
          : null}
      </MapContainer>
    </div>
  );
}
