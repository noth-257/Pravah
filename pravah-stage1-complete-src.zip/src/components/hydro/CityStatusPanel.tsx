import { AlertTriangle } from "lucide-react";
import { ALERTS, CITY_STATUS, RISK_LABEL } from "@/lib/hydro/data";
import { riskBorder, riskText } from "@/lib/hydro/ui";
import { cn } from "@/lib/utils";
import { DataTag, Metric, Panel } from "./primitives";

export function CityStatusPanel({ className }: { className?: string }) {
  return (
    <div className={cn("flex min-h-0 flex-col gap-3", className)}>
      <Panel title="Current City Status" action={<DataTag kind="LIVE" />} bodyClassName="p-3">
        <div className="grid grid-cols-2 gap-2.5">
          <Metric
            label="Flood Risk Level"
            value={RISK_LABEL[CITY_STATUS.riskLevel].toUpperCase()}
            tone={CITY_STATUS.riskLevel}
            sub="City-wide composite"
          />
          <Metric
            label="Areas at Critical Risk"
            value={CITY_STATUS.criticalAreas}
            tone="critical"
            sub="of 80 wards"
          />
          <Metric
            label="Active Water Sensors"
            value={`${CITY_STATUS.sensorsOnline} / ${CITY_STATUS.sensorsTotal}`}
            sub="4 offline · 1 delayed"
          />
          <Metric
            label="Rainfall Intensity"
            value={CITY_STATUS.rainfallIntensity}
            unit="mm/hr"
            tone="primary"
            sub={`${CITY_STATUS.rainfall1h} mm last hour`}
          />
        </div>
      </Panel>

      <Panel
        title={
          <span className="flex items-center gap-1.5">
            <AlertTriangle className="size-3.5 text-high" /> Critical Alerts
          </span>
        }
        action={<span className="num text-xs text-muted-foreground">{ALERTS.length} active</span>}
        className="min-h-0 flex-1"
        bodyClassName="overflow-auto p-3"
      >
        <ul className="space-y-2">
          {ALERTS.map((a) => (
            <li
              key={a.id}
              className={cn(
                "rounded-md border bg-surface px-3 py-2.5 transition-colors hover:border-border-strong",
                riskBorder[a.level],
              )}
            >
              <div className="flex items-start gap-2">
                <span className={cn("mt-1 size-2 shrink-0 rounded-full bg-current", riskText[a.level])} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-medium text-foreground">{a.title}</p>
                    <DataTag kind={a.tag} />
                  </div>
                  <p className="mt-0.5 text-xs font-medium text-foreground/70">{a.location}</p>
                  <p className="num mt-1 text-xs text-muted-foreground">{a.detail}</p>
                  <p className="mt-1.5 text-[10px] tracking-[0.1em] text-muted-foreground/80 uppercase">
                    {a.age}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
